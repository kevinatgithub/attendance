package dev.kevin.app.qrtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Selfie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selfie);

        CameraController cameraController = new CameraController(this);
        cameraController.getCameraInstance();

        cameraController.takePicture();
    }
}
